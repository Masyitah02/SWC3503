<?php
    include "session_expiry.php";
    include_once 'config.php';
    include_once 'fetch_data.php';

    if ($_SESSION['userType'] !== 'admin') exit(header('location: index.php'));
    $edit_mode = $_GET['mode'] ?? '';
    $create_new_url = '';
    $create_new_url = $edit_mode === 'books' ? 'books.php?mode=new' : 'users.php?mode=new';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Inventory</title>
    <link rel="stylesheet" href="css/style.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
</head>
<body>
    <main>
        <div class="header">
            <h1>Library Inventory</h1>
            <a href="logout.php" class="log-out">↩ Log Out</a>
        </div>
        <section class="admin-nav">
            <a href="index.php" class="btn-nav">Home</a>
            <a href="manager.php?mode=books" class="btn-nav">Manage Books</a>
            <a href="manager.php?mode=users" class="btn-nav">Manage Users</a>
        </section>
        <div style="width:100%; display: flex; align-items: center; margin-top: 1.15rem">
            <div class="page-title"><?= ucfirst($edit_mode) ?></div>
            <!-- <?= ucfirst($edit_mode) ?> -->
            <a class="btn-new" href="<?= $create_new_url ?>">+ Add New</a>
        </div>
        <section class="books-list-container">
            <table>
                <?php
                    $books = getAllBooks($libDb);
                    $users = getAllUsers($libDb);
                ?>
                <?php if ($edit_mode === 'books') { ?>
                    <tr>
                        <th><div class="title">Books</div></th>
                        <th><div class="author">Author</div></th>
                        <th><div class="publisher">Publisher</div></th>
                        <th><div class="ISBN">ISBN</div></th>
                        <th><div class="version">Version</div></th>
                        <th><div>Action</div></th>
                    </tr>
                <?php foreach($books as $book): ?>
                    <tr>
                        <td><?= $book['book'] ?></td>
                        <td><?= $book['author'] ?></td>
                        <td><?= $book['publisher'] ?></td>
                        <td><?= $book['isbn'] ?></td>
                        <td><?= $book['version'] ?></td>
                        <td class="actions">
                            <button class="btn-action btn-update"
                            data-id="<?= $user['book_id'] ?>">
                                <a href="books.php?mode=update&id=<?= $book['book_id'] ?>">Update</a>
                            </button>
                            <button class="btn-action btn-delete" data-id="<?= $book['book_id'] ?>" data-name="<?= $book['book'] ?>">
                                Delete
                            </button>
                        </td>
                    </tr>
                <?php endforeach ?>
                <?php } ?>

                <?php if ($edit_mode === 'users') { ?>
                    <tr>
                        <th><div class="username">Username</div></th>
                        <th><div class="email">Email</div></th>
                        <th><div class="user-type">User Type</div></th>
                        <th><div class="reg-date">Registration Date</div></th>
                        <th><div>Action</div></th>
                    </tr>
                <?php foreach($users as $user): ?>
                    <tr>
                        <td><?= $user['username'] ?></td>
                        <td><?= $user['email'] ?></td>
                        <td><?= $user['user_type'] ?></td>
                        <td><?= $user['registration_date'] ?></td>
                        <td class="actions">
                            <button class="btn-action btn-update"
                            data-id="<?= $user['user_id'] ?>">
                                <a href="users.php?mode=update&id=<?= $user['user_id'] ?>">Update</a>
                            </button>
                            <button class="btn-action btn-delete" data-id="<?= $user['user_id'] ?>" data-name="<?= $user['username'] ?>">
                                Delete
                            </button>
                        </td>
                    </tr>
                <?php endforeach ?>
                <?php } ?>
            </table>
        </section>

        <!-- Modal/Dialog -->
        <dialog class="dialog" id="dialog1" aria-hidden="true">
            <div tabindex="-1">
                <div class="dialog-content">
                    <header>
                        <h2>Update <?= ucfirst($_GET['mode']) ?></h2>
                        <button class="btn-close-dialog" data-target="dialog1">
                            Close
                        </button>
                    </header>
                    <div class="form-container--user">
                        <form action="process_data.php" method="POST">
                            <input type="hidden" name="id" id="id" value="">
                            <input type="hidden" name="mode" value="<?= $_GET['mode'] ?>">
                            <?php if ($_GET['mode'] === 'books') { ?>
                            <div class="form-group">
                                <label for="book">Book Name</label>
                                <input type="text" name="book" id="book" required>
                            </div>
                            <div class="form-group">
                                <label for="author">Author</label>
                                <input type="text" name="author" id="author" required>
                            </div>
                            <div class="form-group">
                                <label for="publisher">Publisher</label>
                                <input type="text" name="publisher" id="publisher" required>
                            </div>
                            <div class="form-group">
                                <label for="isbn">ISBN</label>
                                <input type="text" name="isbn" id="isbn" required>
                            </div>
                            <div class="form-group">
                                <label for="version">Version</label>
                                <input type="text" name="version" id="version">
                            </div>
                            <?php } ?>
                            
                            <?php if ($_GET['mode'] === 'users') { ?>
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" name="username" id="username" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" name="email" id="email" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" name="password" id="password" required>
                            </div>
                            <div class="form-group">
                                <label for="userType">User Type</label>
                                <select name="userType" id="userType">
                                    <option value="user">User</option>
                                    <option value="librarian">Librarian</option>
                                </select>
                            </div>
                            <?php } ?>

                            <button type="submit" name="submit" class="btn-submit">
                                Update
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </dialog>
        <dialog class="dialog" id="dialogDelete">
            <div tabindex="-1">
            <div class="dialog-content">
                    <h2 style="margin-bottom: 0.5rem;">Delete</h2>
                    <div class="form-container--user">
                        <span class="dialog-subtext">Are you sure want to delete </span>
                        <form action="delete_data.php" method="POST">
                            <input type="hidden" name="id" value="" id="id">
                            <input type="hidden" name="type" value="<?= $edit_mode ?>">
                            <div class="dialog-btns">
                                <button class="btn-close-dialog" data-target="dialogDelete">
                                    Cancel
                                </button>
                                <button type="submit" name="submit" class="btn-submit-delete">
                                    Delete
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </dialog>
    </main>
    <table id="example-table">

    </table>
</body>
<script>
    const dialogUpdate = document.getElementById('dialog1');
    const dialogDelete = document.getElementById('dialogDelete');

    const openDialogUpdate = document.querySelectorAll('.open-dialog-update');
    const closeBtns = document.querySelectorAll('.btn-close-dialog');
    const deleteBtns = document.querySelectorAll('.btn-delete');

    for (let btn of deleteBtns) {
        btn.addEventListener("click", e => {
            const id = btn.dataset.id;
            const name = btn.dataset.name;
            const subtext = dialogDelete.querySelector('.dialog-subtext');
            const idInput = dialogDelete.querySelector('#id');
            idInput.value = id;
            subtext.innerText = `Are you sure want to delete '${name}'?`;

            console.log(subtext);
            dialogDelete.showModal();
            e.stopPropagation();
        });
    }
    
    for (let btn of openDialogUpdate) {
        btn.addEventListener("click", e => {
            const itemId = dialogUpdate.querySelector('#id');
            itemId.value = btn.dataset.id;
            dialogUpdate.showModal();
        })
    }
    for(let btn of closeBtns) {
        btn.addEventListener("click", e => {
            e.preventDefault();
            document.getElementById(btn.dataset.target).close();
        })
    }
    
</script>
</html>