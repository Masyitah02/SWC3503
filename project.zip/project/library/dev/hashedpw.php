<?php 
    require_once "../config.php";
    // admin - admin123, user1 - 123456
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    // INSERT INTO users (username, password, email, user_type) 
    // VALUES ('newuser', 'hashed_password', 'newuser@email.com', 'user');

    // $new_password = '123456';
    // $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
    // $query = "UPDATE users SET password = ? WHERE username = 'user1'";

    echo $query;

    if ($stmt = $libDb->prepare($query)) {
        $stmt->bind_param("s", $hashed_password);
        if ($stmt->execute()) {
            echo 'S';
        } else {
            echo 'F';
        }
        $stmt->close();
    } else {
        // echo 'Prepare statement failed ' . $stmt->error;
    }
?>