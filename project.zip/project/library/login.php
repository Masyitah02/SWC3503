<?php
    include "session_expiry.php";
    require_once "config.php";

    $usernameInp = "";
    $passwordInp = "";
    $usernameErr = "";
    $passwordErr = "";

    if (isset($_POST['submit'])) {
        if (empty(trim($_POST['username']))) {
            $usernameErr = "Please enter username";
            $_SESSION['usernameErr'] = $usernameErr;
        } else {
            $usernameInp = trim($_POST['username']);
        }
        if (empty(trim($_POST['password']))) {
            $passwordErr = "Please enter password";
            $_SESSION['passwordErr'] = $passwordErr;
        } else {
            $passwordInp = trim($_POST['password']);
        }

        if (empty($usernameErr) && empty($passwordErr)) {
            $loginQuery = "SELECT * FROM users WHERE username = ?";

            if ($stmt = $libDb->prepare($loginQuery)) {
                $stmt->bind_param("s", $usernameInp);

                if ($stmt->execute()) {
                    $stmt->store_result();

                    if ($stmt->num_rows > 0) {
                        $stmt->bind_result($id, $username, $password, $email, $userType, $registerDate);
    
                        while ($stmt->fetch()) {
                            if (password_verify($passwordInp, $password)) {
                                echo $id . ' ' . $username;
                                $_SESSION['userId'] = $id;
                                $_SESSION['username'] = $username;
                                $_SESSION['email'] = $email;
                                $_SESSION['userType'] = $userType;
                                $_SESSION['lib_logged_in'] = true;

                                session_regenerate_id();
                                exit(header('location: index.php'));
                            } else {
                                $passwordErr = 'Password is incorrect';
                                $_SESSION['passwordErr'] = $passwordErr;
                            }
                        }
                    } else {
                        $usernameErr = 'No username found with that username';
                        $_SESSION['usernameErr'] = $usernameErr;    
                    }
                } 
                $stmt->close();
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Library Inventory</title>
    <link rel="stylesheet" href="css/login.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
</head>
<body>
    <main>
        <div class="form-container">
            <div class="title">Library Inventory</div>
            <form action="" method="POST">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" value=<?= $_POST['username'] ?? '' ?>>
                    <span class="label-err">
                    <?php
                        if (isset($_SESSION['usernameErr']) && !empty($_SESSION['usernameErr'])) {
                            echo $_SESSION['usernameErr'];
                            unset($_SESSION['usernameErr']);
                        }
                    ?>
                    </span>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password">
                    <span class="label-err">
                    <?php
                        if (isset($_SESSION['passwordErr']) && !empty($_SESSION['passwordErr'])) {
                            echo $_SESSION['passwordErr'];
                            unset($_SESSION['passwordErr']);
                        }
                    ?>
                    </span>
                </div>
                <button type="submit" name="submit" class="btn-login">Login</button>
            </form>
        </div>
    </main>
</body>
</html>