<?php
    // for sign up
    if (isset($_POST['register'])) {
        if (empty(trim($_POST['username']))) {
            $usernameErr = "Please enter your username";
        } else if (!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST['username']))) { // can only contain letters, numbers, and underscores
            $usernameErr = "Username can only contain letters, numbers, and underscores";
        } else {
            $query = "SELECT id FROM users WHERE username = ?";

            if ($stmt = mysqli_prepare($libDb, $query)) {
                mysqli_stmt_bind_param($stmt, "s", $param_username);

                // Set parameter
                $param_username = trim($_POST['username']);

                if (mysqli_stmt_execute($stmt)) {
                    mysqli_stmt_store_result($stmt);

                    if (mysqli_stmt_num_rows($stmt) == 1) {
                        $usernameErr = "This username is already taken";
                    } else {
                        $username = trim($_POST['username']);
                    }
                } else {
                    echo 'Something went wrong. Please try again later.';
                }

                mysqli_stmt_close($stmt);
            }
        }

        if (empty(trim($_POST['password']))) {
            $passwordErr = "Please enter a password";
        } else if (strlen(trim($_POST['password'])) < 6) {
            $passwordErr = "Password must have at least 6 characters";
        } else {
            $password = trim($_POST['password']);
        }


        // Check input errors
        if (empty($usernameErr) && empty($passwordErr)) {
            $query = "INSERT INTO users ";

            if ($stmt = mysqli_prepare($libDb, $query)) {
                mysqli_stmt_bind_param($stmt, "ss", $paramUser, $paramPass);

                $paramUser = $username;
                $paramPass = password_hash($password, PASSWORD_DEFAULT);

                if (mysqli_stmt_execute($stmt)) {
                    header('location: login.php');
                } else {
                    echo "Something went wrong. Please try again later.";
                }

                mysqli_stmt_close($stmt);
            }
        }
    }

?>