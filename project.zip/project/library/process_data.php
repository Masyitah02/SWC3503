<?php
    session_start();
    include_once "config.php";

    if (!$_SESSION['userType'] === 'admin') exit(header('location: index.php'));

    if (isset($_POST['mode']) && $_POST['mode'] === 'update') {
        if ($_POST['type'] === 'user' && isset($_POST['id'])) {
            // Sanitize the inputs first
            $username = mysqli_real_escape_string($libDb, $_POST['username']) ?? '';
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?? '';
            $userType = mysqli_real_escape_string($libDb, $_POST['userType']) ?? '';
            $id = mysqli_real_escape_string($libDb, $_POST['id']) ?? '';

            $query = "UPDATE users SET username = ?, email = ?, user_type = ? WHERE user_id = ?";
            $stmt = mysqli_prepare($libDb, $query);
            $stmt->bind_param("ssss", $username, $email, $userType, $id);

            if ($stmt->execute()) {
                exit(header('location:manager.php?mode=users&msg=Succesfully update user'));
            } else {
                exit(header('location:manager.php?mode=users&msg=Update failed'));
            }
        } else if ($_POST['type'] === 'book' && isset($_POST['id'])) {
            $book = mysqli_real_escape_string($libDb, $_POST['book']);
            $author = mysqli_real_escape_string($libDb, $_POST['author']);
            $publisher = mysqli_real_escape_string($libDb, $_POST['publisher']);
            $isbn = mysqli_real_escape_string($libDb, $_POST['isbn']);
            $version = mysqli_real_escape_string($libDb, $_POST['version']);
            $id = mysqli_real_escape_string($libDb, $_POST['id']);

            $query = "UPDATE books SET book = ?, author = ?, publisher = ?, isbn = ?, version = ? WHERE book_id = ?";
            $stmt = mysqli_prepare($libDb, $query);
            $stmt->bind_param("ssssss", $book, $author, $publisher, $isbn, $version, $id);

            if ($stmt->execute()) {
                exit(header('location:manager.php?mode=books&msg=Succesfully update $book'));
            } else {
                exit(header('location:manager.php?mode=books&msg=Failed to update $book'));
            }
        } else {
            exit(header('location: index.php'));
        }
    }

    if (isset($_POST['mode']) && $_POST['mode'] === 'new') {
        if ($_POST['type'] === 'user') {
            // Sanitize user inputs
            $username = filter_var($_POST['username'], FILTER_SANITIZE_STRING);
            $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
            $userType = filter_var($_POST['userType'], FILTER_SANITIZE_STRING);

            // Hash the password
            $hashedPassword = password_hash($_POST['password'], PASSWORD_DEFAULT);

            $query =  "INSERT INTO users (username, password, email, user_type) 
            VALUES (?, ?, ?, ?);";
            $stmt = mysqli_prepare($libDb, $query);
            $stmt->bind_param("ssss", $username, $hashedPassword, $email, $userType);

            if ($stmt->execute()) {
                exit(header('location: manager.php?mode=users&msg=New user successfully created'));
            } else {
                exit(header('location: manager.php?mode=users&msg=Failed to create new user'));
            }
        } else if ($_POST['type'] === 'book') {
            $book = mysqli_real_escape_string($libDb, $_POST['book']);
            $author = mysqli_real_escape_string($libDb, $_POST['author']);
            $publisher = mysqli_real_escape_string($libDb, $_POST['publisher']);
            $isbn = mysqli_real_escape_string($libDb, $_POST['isbn']);
            $version = mysqli_real_escape_string($libDb, $_POST['version']);
            $id = mysqli_real_escape_string($libDb, $_POST['id']);

            $query = "INSERT INTO books (book, author, publisher, isbn, version)
            VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($libDb, $query);
            $stmt->bind_param("sssss", $book, $author, $publisher, $isbn, $version);

            if ($stmt->execute()) {
                exit(header('location:manager.php?mode=books&msg=Succesfully added a new book'));
            } else {
                exit(header('location:manager.php?mode=books&msg=Failed to add a new book'));
            }
        } else {
            exit(header('location: index.php'));
        }
    }
?>