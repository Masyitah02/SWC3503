<?php
    session_start();
    include 'config.php';
    include 'fetch_data.php';

    $title = '';
    $book;

    if (isset($_GET['mode'])) {
        if ($_GET['mode'] === 'update') {
            if (isset($_GET['id'])) {
                $id = $_GET['id'];
                $book = getBook($libDb, $id);
            } else {
                exit(header('location: manager.php?mode=books'));
            }
        }
    } else {
        exit(header('location: manager.php?mode=books'));
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book</title>
    <style>
        html, body {
            height: 100%;
        }
    </style>
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="form-container">
            <div class="title">
                <?= isset($book) ? 'Update Book' : 'Add New Book' ?>
            </div>
            <form action="process_data.php" method="POST">
                <input type="hidden" name="id"
                value="<?= isset($book) ? htmlspecialchars($book['book_id']) : '' ?>">
                <input type="hidden" name="type" value="book">
                <input type="hidden" name="mode" value="<?= $_GET['mode'] ?>">
                <div class="form-group">
                    <label for="book">Title</label>
                    <input type="text" name="book" id="book"
                    value="<?= isset($book) ? htmlspecialchars($book['book']) : '' ?>" required>
                </div>
                <div class="form-group">
                    <label for="author">Author</label>
                    <input type="text" name="author" id="author" 
                    value="<?= isset($book) ? htmlspecialchars($book['author']) : '' ?>" required>
                </div>
                <div class="form-group">
                    <label for="publisher">Publisher</label>
                    <input type="text" name="publisher" id="publisher" 
                    value="<?= isset($book) ? htmlspecialchars($book['publisher']) : '' ?>" required>
                </div>
                <div class="form-group">
                    <label for="isbn">ISBN</label>
                    <input type="text" name="isbn" id="isbn" 
                    value="<?= isset($book) ? htmlspecialchars($book['isbn']) : '' ?>" required>
                </div>
                <div class="form-group">
                    <label for="version">Version</label>
                    <input type="text" name="version" id="version" 
                    value="<?= isset($book) ? htmlspecialchars($book['version']) : '' ?>" required>
                </div>
                <button type="submit" name="submit" class="btn-submit">
                    <?= isset($book) ? 'Update Book' : 'Add Book' ?>
                </button>
            </form>
        </div>
    </div>
</body>
</html>