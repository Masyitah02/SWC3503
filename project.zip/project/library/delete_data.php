<?php
    session_start();
    include_once "config.php";

    if (!$_SESSION['userType'] === 'admin') exit(header('location: index.php'));
    if (isset($_POST['type']) && isset($_POST['id'])) {
        // echo 'sini'; exit();
        $query = '';
        $redirectUrl = 'manager.php';
        if ($_POST['type'] === 'users') {
            $query = "DELETE FROM users WHERE user_id = ?";
            $redirectUrl .= '?mode=users';
        } else if ($_POST['type'] === 'books') {
            $query = "DELETE FROM books WHERE book_id = ?";
            $redirectUrl .= '?mode=books';
        } else {
            exit(header('location: index.php'));    
        }

        $id = mysqli_real_escape_string($libDb, $_POST['id']);

        $stmt = $libDb->prepare($query);
        $stmt->bind_param("s", $id);
        $stmt->execute();
        
        if ($stmt->affected_rows > 0) {
            // Successful delete
            $redirectUrl .= '&msg=Successfully deleted';
        } else {
            // No rows affected - handle update case
            $redirectUrl .= '&msg=No rows affected';
        }
    
        $stmt->close();
        $libDb->close();

        exit(header("location: $redirectUrl"));
    } else {
        exit(header('location: index.php'));
    }
?>