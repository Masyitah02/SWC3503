<?php
    include "session_expiry.php";
    include 'fetch_data.php';
    date_default_timezone_set('Asia/Kuala_Lumpur');

    if (!isset($_SESSION['lib_logged_in'])) {  
        exit(header('location: login.php'));
    }

    $userType = $_SESSION['userType']; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Inventory</title>
    <link rel="stylesheet" href="css/style.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
</head>
<body>
    <main>
        <div class="header">
            <h1>Library Inventory</h1>
            <a href="logout.php" class="log-out">↩ Log Out</a>
        </div>
        <section class="top-section">
            <div>
                <div class="hello-username">Hello, <span><?= $_SESSION['username'] ?? 'User' ?></span></div>
                <div class="current-date"><?= date('d-m-Y g:i A') ?></div>
            </div>
            <div class="total-books-container">
                <div class="total-books-label">Total Books in Library</div>
                <div class="total-books-number"><?= countBooks($libDb) ?></div>
            </div>
        </section>
        <?php if ($userType === 'admin') { ?>

        <section class="admin-nav">
            <a href="manager.php?mode=books" class="btn-nav">Manage Books</a>
            <a href="manager.php?mode=users" class="btn-nav">Manage Users</a>
        </section>

        <?php } ?>
        
        <section class="books-list-container">
            <table>
            <?php $books = getAllBooks($libDb); ?>
                    <tr>
                        <th><div class="title">Books</div></th>
                        <th><div class="author">Author</div></th>
                        <th><div class="publisher">Publisher</div></th>
                        <th><div class="ISBN">ISBN</div></th>
                        <th><div class="version">Version</div></th>
                    </tr>
                <?php foreach($books as $book): ?>
                    <tr>
                        <td><?= $book['book'] ?></td>
                        <td><?= $book['author'] ?></td>
                        <td><?= $book['publisher'] ?></td>
                        <td><?= $book['isbn'] ?></td>
                        <td><?= $book['version'] ?></td>
                    </tr>
                <?php endforeach ?>
                <!-- List of books here generated from backend data -->
            </table>
        </section>
    </main>
</body>
</html>