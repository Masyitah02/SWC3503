<?php
    include_once 'config.php';

    function getAllUsers($db) {
        $query = "SELECT * FROM users";
        $result = mysqli_query($db, $query);

        if ($result) {
            $rows = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $rows[] = $row;
            }

            mysqli_free_result($result);
            return $rows;
        }

        return array();
    }
    function getUser($db, $id) {
        $query = "SELECT * FROM users WHERE user_id=?";

        $stmt = mysqli_prepare($db, $query);
        $stmt->bind_param("s", $id);
        
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $stmt->close();
            return $row;
        } else {
            return array();
        }
    }
    function getAllBooks($db) {
        $query = "SELECT * FROM books";
        $result = mysqli_query($db, $query);

        if ($result) {
            $rows = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $rows[] = $row;
            }

            mysqli_free_result($result);
            return $rows;
        }

        return array();
    }
    function getBook($db, $id) {
        $query = "SELECT * FROM books WHERE book_id=?";

        $stmt = mysqli_prepare($db, $query);
        $stmt->bind_param("s", $id);
        
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $stmt->close();
            return $row;
        } else {
            return array();
        }
    }
    function countBooks($db) {
        $query = "SELECT COUNT(*) AS noOfBooks FROM books;";
        $result = $db->query($query);

        if ($result) {
            $row = $result->fetch_assoc();
            $count = $row['noOfBooks'];
            return $count;
        }
        return 0;
    }

    if (isset($_GET['allUsers'])) {
        $users = getAllUsers($libDb);
        header('Content-Type: application/json');
        echo json_encode($users);
    }
    // For AJAX
    if (isset($_GET['allBooks'])) {
        $books = getAllBooks($libDb);
        header('Content-Type: application/json');
        echo json_encode($books);
    }
?>