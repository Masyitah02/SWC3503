<?php
    define('DB_SERVER', 'localhost');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '');
    define('DB_USER', 'library_inventory');
    
    $libDb = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_USER);

    if ($libDb === false) {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }
?>