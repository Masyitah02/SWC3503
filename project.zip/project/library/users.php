<?php
    session_start();
    include 'config.php';
    include 'fetch_data.php';

    $title = '';
    $user;

    if (isset($_GET['mode'])) {
        if ($_GET['mode'] === 'update') {
            if (isset($_GET['id'])) {
                $id = $_GET['id'];
                $user = getUser($libDb, $id);
            } else {
                exit(header('location: manager.php?mode=users'));
            }
        }
    } else {
        exit(header('location: manager.php?mode=users'));
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
    <style>
        html, body {
            height: 100%;
        }
    </style>
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="form-container">
            <div class="title">
                <?= isset($user) ? 'Update User' : 'Create New User' ?>
            </div>
            <form action="process_data.php" method="POST">
                <input type="hidden" name="id"
                value="<?= isset($user) ? htmlspecialchars($user['user_id']) : '' ?>">
                <input type="hidden" name="type" value="user">
                <input type="hidden" name="mode" value="<?= $_GET['mode'] ?>">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" name="username" id="username"
                    value="<?= isset($user) ? htmlspecialchars($user['username']) : '' ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" 
                    value="<?= isset($user) ? htmlspecialchars($user['email']) : '' ?>" required>
                </div>
                <div class="form-group">
                    <label for="userType">User Type</label>
                    <select name="userType" id="userType">
                        <option value="user" <?= (isset($user) && $user['user_type'] === 'user') ? 'selected' : ''?>>User</option>
                        <option value="admin" <?= (isset($user) && $user['user_type'] === 'admin') ? 'selected' : ''?> >Librarian</option>
                    </select>
                </div>
                <?php if ($_GET['mode'] === 'new') { ?>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" required>
                    </div>
                <?php } ?>
                <button type="submit" name="submit" class="btn-submit">
                    <?= isset($user) ? 'Update' : 'Create new user' ?>
                </button>
            </form>
        </div>
    </div>
</body>
</html>