<?php
    session_start();
    $sessionExpiration = 180; // 30 minutes

    // Check the last activity time
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $sessionExpiration)) {
        session_unset();
        session_destroy();

        // Redirect to the login page with an expired flag
        header('Location: login.php?expired=1');
        exit();
    } else {
        // Update last activity time
        $_SESSION['last_activity'] = time();
    }
?>